
<!DOCTYPE html>
<html lang="en">

    <!-- Head -->
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Messenger - Responsive Bootstrap Application</title>

        <!-- Prism -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.17.1/themes/prism-tomorrow.min.css" rel="stylesheet">

        <!-- Template core CSS -->
        <link href="../assets/css/template.min.css" rel="stylesheet">
        <link href="../assets/css/template.dark.min.css" rel="stylesheet" media="(prefers-color-scheme: dark)">
    </head>
    <!-- Head -->

    <body class="" data-spy="scroll" data-target="#docs-sub-navigation" data-offset="200">

        <!-- Navbar -->
        <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-basic border-bottom py-3">
            <div class="container-fluid">

                <!-- Brand -->
                <a class="navbar-brand mr-0" href="../index.php">
                    <img src="../assets/images/brand.svg" class="mx-auto fill-primary" data-inject-svg="" style="width: 46px;">
                </a>

                <!-- Toggler -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <!-- Nav -->
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="navbar-item">
                            <a class="nav-link" href="index.php">Introduction</a>
                        </li>

                        <li class="navbar-item">
                            <a class="nav-link" href="changelog.php">Changelog</a>
                        </li>

                        <li class="navbar-item">
                            <a class="nav-link" href="alert.php">Components</a>
                        </li>

                        <li class="navbar-item">
                            <a class="nav-link" href="index.php#Support">Support</a>
                        </li>
                    </ul>

                    <ul class="navbar-nav ml-auto">
                        <li class="navbar-item">
                            <a class="nav-link" href="../index.php">
                                Back to Messenger
                                <span class="ml-1">→</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Navbar -->

        <section class="" style="padding-top: 77px;">
            <div class="container-fluid">

                <div class="row align-items-top">

                    <!-- Sidebar -->
                    <div class="col-lg-2 py-8 border-right"  style="position: fixed;top: 77px;height: calc(100vh - 77px);overflow: auto;">
                        <div>
                            <h5 class="mb-6">Getting started</h5>
                            <ul class="list-unstyled mb-8">
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="index.php">Introduction</a>
                                </li>
                                <li class="list-item d-flex">
                                    <a class="text-muted" href="changelog.php">Changelog</a>
                                    <span class="badge badge-pill badge-secondary ml-auto align-self-center">1.1</span>
                                </li>
                            </ul>

                            <h5 class="mb-6">Components</h5>
                            <ul class="list-unstyled mb-8">
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="alert.php">Alerts</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="avatar.php">Avatars</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="badge.php">Badges</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="buttons.php">Buttons</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="cards.php">Cards</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="collapse.php">Collapse</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="dropdowns.php">Dropdowns</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="forms.php">Forms</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="icons.php">Icons</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="lists.php">List group</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="modal.php">Modal</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="navs.php">Navs</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="popovers.php">Popovers</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="progress.php">Progress</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="tables.php">Tables</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="toasts.php">Toasts</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="typography.php">Typography</a>
                                </li>
                            </ul>

                            <h5 class="mb-6">Utilities</h5>
                            <ul class="list-unstyled mb-8">
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="opacity.php">Opacity</a>
                                </li>
                                <li class="list-item d-flex">
                                    <a class="text-muted" href="fill.php">Fill</a>
                                </li>
                            </ul>

                            <h5 class="mb-6">Plugins</h5>
                            <ul class="list-unstyled mb-8">
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="autosize.php">Autosize</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="dropzonejs.php">DropzoneJS</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="svg-injector.php">SVGInjector</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="emoji.php">Emoji</a>
                                </li>
                                <li class="list-item mb-3">
                                    <a class="text-muted" href="zoom-vanilla.php">zoom-vanilla.js</a>
                                </li>
                            </ul>

                        </div>
                    </div><!-- .col-lg-3 -->

                    <!-- Content -->
                    <div class="col-lg-8 offset-lg-2 py-10 px-lg-10">
                        <h1 class="font-normal mb-2">Introduction</h1>
                        <p class="lead">Learn how to use template using NPM scripts to build your chat, compile SCSS, change brand-colors and more.</p>

                        <hr class="my-9">

                        <h3 class="font-normal" data-create-link="#">Installing Node.js</h3>
                        <p>If you do not have Node installed already, you can get it by downloading the package installer from Node's website. You need to have Node.js installed onto your computer before you can install Gulp. <a href="#">Download and install Node.js →</a></p>

                        <hr class="my-9">

                        <h3 class="font-normal" data-create-link="#">Installing Gulp</h3>
                        <p>Download Gulp Command Line Interface to be able to use <b class="text-basic-inverse">gulp</b> in your terminal.</p>
                        <pre class="bg-light py-6 my-5">
                            <code class="language-markup">
                                <script type="prism-html-markup">
                                    npm install gulp-cli -g
                                </script>
                            </code>
                        </pre>

                        <hr class="my-9">

                        <h3 class="font-normal" data-create-link="#">Installing NPM modules</h3>
                        <p>Open your command line to the root directory of your unzipped theme and run to install all of theme's dependencies.</p>
                        <pre class="bg-light py-6 my-5">
                            <code class="language-markup">
                                <script type="prism-html-markup">
                                    npm install
                                </script>
                            </code>
                        </pre>

                        <hr class="my-9">

                        <h3 class="font-normal" data-create-link="#">Run Gulp</h3>
                        <p>Template employs Browsersync to serve pages from the dist directory. Running gulp will compile the theme, copy all required files to the dist directory and will open a browser window to dist/index.html. Now you can try making some changes to assets/include/scss/template.scss and save it.</p>
                        <pre class="bg-light py-6 my-5">
                            <code class="language-markup">
                                <script type="prism-html-markup">
                                    gulp
                                </script>
                            </code>
                        </pre>
                        <p><span class="font-medium text-basic-inverse">Important:</span> Be aware that this replaces existing "dist" files, so proceed with caution.</p>
                        <p>Hit Ctrl+C or just close the command line window to stop the server.</p>

                        <hr class="my-9">

                        <h3 class="font-normal" data-create-link="#">HTML includes</h3>
                        <p>
                            The <a href="https://www.npmjs.com/package/gulp-file-include" target="_blank">gulp-file-include</a> package is used to make global changes in HTML files easier. The following partials are available:
                        </p>
                        <ul class="text-gray-700">
                            <li>
                                <code>head.html</code>
                                <ul>
                                    <li>
                                        <code>auto (string)</code> - Parameter for switching between auto, dark and light themes. Can be either "auto", "dark",  or "light"
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <p>
                            Easily create new <code>.html</code> partials inside the <code>/partials</code> folder and point to them from any file by specifying the path to the partial file and using the <code>@@include</code> keyword.
                        </p>
                        <p>
                            Please read the <a href="https://www.npmjs.com/package/gulp-file-include" target="_blank">official package documentation</a> for more info.
                        </p>

                        <hr class="my-9">

                        <h3 class="font-normal" data-create-link="#">Customizing SCSS</h3>
                        <p>There are 2 basic ways to customize your theme:</p>
                        <ol>
                            <li>
                                <strong>Customizing SCSS.</strong> This is more versatile and sustainable way to customize the template, but requires the <code>gulp</code> compilation steps outlined above. The 2 major benefits of this strategy are using variable overrides to easily customize theme styles, plus you never have to touch Bootstrap or template's source, meaning future updates will be much, much, simpler. There are 3 provided files that make this strategy simple to implement:
                                <ul>
                                    <li>
                                        <code>user-variables.scss</code> or <code>user-variables.dark.scss</code>: This files can be used to override Bootstrap core and the template variables for customizing elements that have been tied to variables.
                                    </li>
                                    <li>
                                        <code>user.scss</code>: This file can be used for writing custom SCSS that will be compiled alongside Bootstrap and template's core files.
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <strong>Compiled CSS.</strong> If you plan on using the template "as is", or only need limited customization, feel free to simply attach the compiled <code>template.css</code>, <code>template.dark.css</code> or <code>template.min.css</code>, <code>template.dark.min.css</code> file in the <code>dist/assets/css</code> directory.
                            </li>
                        </ol>

                        <hr class="my-9">

                        <h3 class="font-normal" data-create-link="#">Themes</h3>
                        <p>You can use Messenger with <code>auto</code>, <code>dark</code> or <code>light</code> mode. By default we use <code>auto</code> mode.</p>

                        <pre class="bg-light py-6 my-5">
                            <code class="language-markup">
                                <script type="prism-html-markup">
                                    <!-- Head -->
                                    ...include("particles/head/head.html", { "theme": "auto" })
                                    <!-- Head -->
                                </script>
                            </code>
                        </pre>

                        <h5 class="font-normal">Dark only:</h5>

                        <pre class="bg-light py-6 my-5">
                            <code class="language-markup">
                                <script type="prism-html-markup">
                                    <!-- Head -->
                                    ...include("particles/head/head.html", { "theme": "dark" })
                                    <!-- Head -->
                                </script>
                            </code>
                        </pre>

                        <h5 class="font-normal">Light only:</h5>

                        <pre class="bg-light py-6 my-5">
                            <code class="language-markup">
                                <script type="prism-html-markup">
                                    <!-- Head -->
                                    ...include("particles/head/head.html", { "theme": "light" })
                                    <!-- Head -->
                                </script>
                            </code>
                        </pre>
                        <p><span class="font-medium text-basic-inverse">Important:</span> Use "@@" instead of "..."</p>

                        <hr class="my-9">

                        <h3 class="font-normal" data-create-link="#">Support</h3>
                        <p>We provide support and guidance for this product. Please feel free to email here: web-master72[at]yandex.com</p>

                    </div><!-- .col-lg-10 -->

                    <!-- Sidebar -->
                    <div class="col-lg-2 border-left my-8 py-4" style="position: fixed; right: 0;">
                        <nav id="docs-sub-navigation" class="nav flex-column mb-0">
                            <h6 class="nav-link py-2">Jump to:</h6>
                        </nav>
                    </div><!-- .col-lg-2 -->
                </div>


            </div>
        </section>


        <!-- Scripts -->
        <script src="../assets/js/libs/jquery.min.js"></script>
        <script src="../assets/js/bootstrap/bootstrap.bundle.min.js"></script>
        <script src="../assets/js/plugins/plugins.bundle.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.17.1/components/prism-core.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.17.1/plugins/autoloader/prism-autoloader.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.17.1/plugins/normalize-whitespace/prism-normalize-whitespace.min.js"></script>
        <script src="../assets/js/template.js"></script>

        <script>
            (function($){

                "use strict";

                $(document).ready(function() {

                    $(function () {
                        $('[data-toggle="popover"]').popover()
                    })

                    //

                    $('[data-create-link]').each(function () {

                        let margin,
                            text      = $(this).text(),
                            text_hash = text.replace(/:/g, '_');
                            text_hash = text.replace(/ /g, '_');

                        $(this).attr('id', text_hash);

                        if ( $(this).is('h4, h5, h6') == true ) {
                            margin = 'ml-5';
                        }

                        $('#docs-sub-navigation').append($( `<a href="#${text_hash}" class="nav-link text-muted py-2 ${margin}" data-toggle="smooth-scroll">${text}</a>` ));
                    });

                    /* ---------------------------------------------- /*
                    * Scroll Animation
                    /* ---------------------------------------------- */

                    $('[data-toggle="smooth-scroll"]').on('click', function(e) {
                        var target  = this.hash;
                        var $target = $(target);
                        $('html, body').stop().animate({
                            'scrollTop':  $target.offset().top - 100
                        }, 600, 'swing');
                        e.preventDefault();
                    });

                });

            })(jQuery);

        </script>
        <!-- Scripts -->
    </body>
</html>