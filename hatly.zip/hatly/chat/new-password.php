<!DOCTYPE html>
<html lang="en">

    <!-- Head -->
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, maximum-scale=1, shrink-to-fit=no">
        <title>Messenger - Responsive Bootstrap Application</title>

        <!-- Template core CSS -->
        
        <link href="assets/css/template.min.css" rel="stylesheet">
        <link href="assets/css/template.dark.min.css" rel="stylesheet" media="(prefers-color-scheme: dark)">
        
        
        
    </head>
    <!-- Head -->

    <body>

        <div class="layout">

            <div class="container d-flex flex-column">
                <div class="row align-items-center justify-content-center no-gutters min-vh-100">

                    <div class="col-12 col-md-5 col-lg-4 py-8 py-md-11">

                        <!-- Heading -->
                        <h1 class="font-bold text-center">Password Reset</h1>

                        <!-- Text -->
                        <p class="text-center mb-6">Enter your New Password.</p>

                        <!-- Form -->
                        <form class="mb-6" method="post" enctype="multipart/form-data">

                            <!-- Email -->
                            <div class="form-group">
                                <label for="password" class="sr-only">New Password</label>
                                <input type="password" name="password" class="form-control form-control-lg" id="password" placeholder="Enter your new password">
                            </div>

                            <!-- Submit -->
                            <button class="btn btn-lg btn-block btn-primary" type="submit" name="submit">Reset Password</button>
                        </form>
						
						
						<?php
						
						
						session_start();

                        $id = $_SESSION['id'];
						$email = $_SESSION['email'];
						
						//echo $email;
						
						include('C:/xampp/htdocs/hatly/Connection/connection.php');
						
						
						//============ Table client======//	
					
					    if($email != ""){		
						if(isset($_POST['submit'])){
						$sql = $con->prepare("SELECT * FROM client");
                        $sql->execute();
                        $rows = $sql->fetchAll();

                        foreach($rows as $pat)
                        {
						
						if($email == $pat['email']){	
							
						
						include('C:/xampp/htdocs/hatly/Connection/connection.php');
						
						$password = $_POST['password'];
						
						$sql = "UPDATE client SET client_password='$password'  WHERE id=$id";

                        $con->exec($sql);
    
                        //header('Location:logout.php');
                        header('Location:signin.php');
						

                        $con=null;
						
						}
						}
						}
						}else{
							
							
							include("log.php");
							include("password-reset.php");
							
						}
						
						//============ Table client======//		
						//============ Table customer_servant======//
						
						include('C:/xampp/htdocs/hatly/Connection/connection.php');
							
						if($email != ""){	
						if(isset($_POST['submit'])){
						$sql = $con->prepare("SELECT * FROM customer_servant");
                        $sql->execute();
                        $rows = $sql->fetchAll();

                        foreach($rows as $pat)
                        {
						
						if($email == $pat['email']){	
							
						
						include('C:/xampp/htdocs/hatly/Connection/connection.php');
						
						$password = $_POST['password'];
						
						$sql = "UPDATE customer_servant SET servant_password='$password'  WHERE id=$id";

                        $con->exec($sql);
    
                        //header('Location:logout.php');
                        header('Location:signin.php');

                        $con=null;
						
						}
						}
						}
						}else{
							
							
							include("log.php");
							include("password-reset.php");
							
						}
						//============ Table customer_servant======//	
							
						?>

                        <!-- Text -->
                        <p class="text-center">
                            Already have an account? <a href="signin.php">Sign in</a>.
                        </p>

                    </div>
                </div> <!-- / .row -->
            </div>

        </div><!-- .layout -->

        <!-- Scripts -->
        <script src="assets/js/libs/jquery.min.js"></script>
        <script src="assets/js/bootstrap/bootstrap.bundle.min.js"></script>
        <script src="assets/js/plugins/plugins.bundle.js"></script>
        <script src="assets/js/template.js"></script>
        <!-- Scripts -->

    </body>
</html>