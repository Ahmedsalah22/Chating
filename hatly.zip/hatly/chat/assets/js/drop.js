        //
        // Dropzone
        //

        if ( document.querySelector('#dropzone-template-js') ) {
            var template = document.querySelector('#dropzone-template-js');
            var template_element = document.querySelector('#dropzone-template-js');
            template_element.parentNode.removeChild(template_element);
        }

        [].forEach.call(document.querySelectorAll('.dropzone-form-js'), function (el) {

            var clickable         = el.querySelector('.dropzone-button-js').id;
            var url               = el.getAttribute('data-dz-url');
            var previewsContainer = el.querySelector('.dropzone-previews-js');

            var myDropzone = new Dropzone(el, {
                url: url,
                previewTemplate: template.innerHTML,
                previewsContainer: previewsContainer,
                clickable: '#' + clickable
            });
        });