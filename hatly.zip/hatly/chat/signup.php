<!DOCTYPE html>
<html lang="en">

    <!-- Head -->
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, maximum-scale=1, shrink-to-fit=no">
        <title>Messenger - Responsive Bootstrap Application</title>

        <!-- Template core CSS -->
        <link href="assets/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
        <link href="assets/select2.min.css" rel="stylesheet" media="all">
        <link href="assets/css/template.min.css" rel="stylesheet">
        <link href="assets/css/template.dark.min.css" rel="stylesheet" media="(prefers-color-scheme: dark)">
        <link rel="stylesheet" href="assets/css/font-awesome.css">
        <link href="assets/css/global.css" rel="stylesheet">
        <link href="assets/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    </head>
    <!-- Head -->

    <body>

        <div class="layout">

            <div class="container d-flex flex-column">
                <div class="row align-items-center justify-content-center no-gutters min-vh-100">

                    <div class="col-12 col-md-5 col-lg-4 py-8 py-md-11">

                        <!-- Heading -->
                        <h1 class="font-bold text-center">Sign up</h1>

                        <!-- Text -->
                        <p class="text-center mb-6">Welcome to the official Chat web-client.</p>

                        <!-- Form -->
                        <form class="mb-6" method="post" action="signup-conn.php" enctype="multipart/form-data">

                            <!-- Name -->
                            <div class="form-group">
                                <label for="fname" class="sr-only">First Name</label>
                                <input type="text" class="form-control form-control-lg" name="fname" id="fname" placeholder="Enter your First Name" required="required">
                            </div>
							
							<div class="form-group">
                                <label for="lname" class="sr-only">Last Name</label>
                                <input type="text" class="form-control form-control-lg" name="lname" id="lname" placeholder="Enter your Last Name" required="required">
                            </div>

                            <!-- Email -->
                            <div class="form-group">
                                <label for="email" class="sr-only">Email Address</label>
                                <input type="email" class="form-control form-control-lg" name="email" id="email" placeholder="Enter your Email" required="required">
                            </div>

                            <!-- Password -->
                            <div class="form-group">
                                <label for="password" class="sr-only">Password</label>
                                <input type="password" class="form-control form-control-lg" name="password" id="password" placeholder="Enter your password" required="required">
                            </div>
                            <div class="form-group">
                                <label for="phone" class="sr-only">Phone Number</label>
                                <input type="tel" class="form-control form-control-lg" name="phone" id="phone" placeholder="Enter your Phone Number" required="required">
                            </div>
							<div class="form-group">
                                <label for="age" class="sr-only">Age</label>
                                <input type="text" class="form-control form-control-lg" name="age" id="age" placeholder="Enter your Age" required="required">
                            </div>
							<div class="form-group">
                                <label for="address" class="sr-only">Address</label>
                                <input type="text" class="form-control form-control-lg" name="address" id="address" placeholder="Enter your Address" required="required">
                            </div>
							<div class="form-group">
                                <label for="gender" class="sr-only">Gender</label>
							    <div class="rs-select2 js-select-simple select--no-search">	
								<select name="gender">
                                    <option disabled="disabled">Gender</option>
                                    <option selected="selected">Male</option>
                                    <option>Female</option>
                                    <option>Other</option>
                                </select>
								<div class="select-dropdown"></div>	
								</div>		
								
                            </div>
							<div class="form-group">
                                <label for="file" class="sr-only">Image</label>
                                <input type="file" class="form-control form-control-lg" name="image" id="image" placeholder="Enter your Image" required="required">
                            </div>
                            <!-- Submit -->
                            <button class="btn btn-lg btn-block btn-primary" type="submit" name="submit">Sign up</button>
                        </form>

                        <!-- Text -->
                        <p class="text-center">
                            Already have an account? <a href="signin.php">Sign in</a>.
                        </p>

                    </div>
                </div> <!-- / .row -->
            </div>

        </div><!-- .layout -->

        <!-- Scripts -->
        <script src="assets/js/libs/jquery.min.js"></script>
        <script src="assets/js/bootstrap/bootstrap.bundle.min.js"></script>
        <script src="assets/js/plugins/plugins.bundle.js"></script>
        <script src="assets/js/template.js"></script>
		<script src="assets/select2.min.js"></script>
		<script src="assets/js/global.js"></script>
        <!-- Scripts -->

    </body>
</html>