<!DOCTYPE html>
<html lang="en">

    <!-- Head -->
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, maximum-scale=1, shrink-to-fit=no">
        <title>Messenger - Responsive Bootstrap Application</title>

        <!-- Template core CSS -->
        
        <link href="assets/css/template.min.css" rel="stylesheet">
        <link href="assets/css/template.dark.min.css" rel="stylesheet" media="(prefers-color-scheme: dark)">
        
        
        
    </head>
    <!-- Head -->

    <body>
<?php


    session_start();

    include('C:/xampp/htdocs/hatly/Connection/connection.php');  
    


//print_r($_POST);
$email = $_POST['email'];
$password = $_POST['password'];
$sql=$con->prepare("SELECT * FROM client WHERE 
 email=? AND client_password=?");
$sql->execute(array($email,$password));
$row=$sql->fetch();
//print_r($row);
$count=$sql->rowCount();
	
//echo "<br>".$count;
if($email != "" && $password != ""){
	
	
if($count>0){
    
	//$na = $_POST["name"];
    //$pa = $_POST["pass"];
    //session_start();
    $sql = $con->prepare("SELECT * FROM client");
    $sql->execute();
    $rows = $sql->fetchAll();

    foreach($rows as $pat)
    {
        if($email == $pat["email"] && $password == $pat["client_password"] && $pat["role"] != 4)
        {
            header('Location:signup.php');
        }
        elseif($email == $pat["email"] && $password == $pat["client_password"])
        {
            $_SESSION['id'] = $pat['id'];
			$_SESSION['fname'] = $pat['first_name'];
			$_SESSION['lname'] = $pat['last_name'];
			$_SESSION['password'] = $pat['client_password'];
			$_SESSION['img'] = $pat['image'];
			$_SESSION['add'] = $pat['address'];
			$_SESSION['mail'] = $pat['email'];
			$_SESSION['phone'] = $pat['phone_number'];
			$_SESSION['role'] = $pat['role'];
			$_SESSION['age'] = $pat['age'];
            header('Location:index.php');
        }
    }
    $con=null;
    echo "wrong password or email";
	
	
	
   
} else{
	
	
	
	  //========= Start Table Customer Servant==========================================//
	
	
	
$sql=$con->prepare("SELECT * FROM customer_servant WHERE 
 email=? AND servant_password=?");
$sql->execute(array($email,$password));
$row=$sql->fetch();
//print_r($row);
$count=$sql->rowCount();
	
//echo "<br>".$count;
if($email != "" && $password != ""){
	
	
if($count>0){
    
	//$na = $_POST["name"];
    //$pa = $_POST["pass"];
    //session_start();
    $sql = $con->prepare("SELECT * FROM customer_servant");
    $sql->execute();
    $rows = $sql->fetchAll();

    foreach($rows as $pat)
    {
        if($email == $pat["email"] && $password == $pat["servant_password"] && $pat["role"] != 2)
        {
            header('Location:register.php');
        }
        elseif($email == $pat["email"] && $password == $pat["servant_password"])
        {
            $_SESSION['id'] = $pat['id'];
			$_SESSION['fname'] = $pat['first_name'];
			$_SESSION['lname'] = $pat['last_name'];
			$_SESSION['password'] = $pat['servant_password'];
			$_SESSION['img'] = $pat['image'];
			$_SESSION['add'] = $pat['address'];
			$_SESSION['mail'] = $pat['email'];
			$_SESSION['phone'] = $pat['phone_number'];
			$_SESSION['role'] = $pat['role'];
			$_SESSION['age'] = $pat['age'];
            header('Location:index.php');
        }
    }
    $con=null;
    echo "wrong password or email";
	
	
	
   
} else{
	
	
	
	
	
echo '

    
	
<div class="alert alert-danger role="alert">
  <strong>Oh Error!</strong> Incorrect email or password and try submitting again.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
	
	<div class="layout">

            <div class="container d-flex flex-column">
                <div class="row align-items-center justify-content-center no-gutters min-vh-100">

                    <div class="col-12 col-md-5 col-lg-4 py-8 py-md-11">

                        <!-- Heading -->
                        <h1 class="font-bold text-center">Sign in</h1>

                        <!-- Text -->
                        <p class="text-center mb-6">Welcome to the official Chat web-client.</p>

                        <!-- Form -->
                        <form class="mb-6" method="post" action="signin-conn.php" enctype="multipart/form-data">
                            <!-- Email -->
                            <div class="form-group">
                                <label for="email" class="sr-only">Email Address</label>
                                <input type="email" name="email" class="form-control form-control-lg" id="email" placeholder="Enter your email">
                            </div>

                            <!-- Password -->
                            <div class="form-group">
                                <label for="password" class="sr-only">Password</label>
                                <input type="password" name="password" class="form-control form-control-lg" id="password" placeholder="Enter your password">
                            </div>

                            <div class="form-group d-flex justify-content-between">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" checked="" id="checkbox-remember">
                                    <label class="custom-control-label" for="checkbox-remember">Remember me</label>
                                </div>
                                <a href="./password-reset.php">Reset password</a>
                            </div>

                            <!-- Submit -->
                            <button class="btn btn-lg btn-block btn-primary" type="submit">Sign in</button>
                        </form>

                        <!-- Text -->
                        <p class="text-center">
                            Do not have an account yet <a href="signup.php">Sign up</a>.
                        </p>

                    </div>
                </div> <!-- / .row -->
            </div>

        </div><!-- .layout -->';
	
  
	  }}else{
	
	
	include('logout.php');
	include('signin.php');
	
	//echo "Not found UserName or password";
}
	
	
//========= End Table Customer Servant==========================================//
	
	
  
	  }}else{
	
	
	include('logout.php');
	include('signin.php');
	
	//echo "Not found UserName or password";
}
	
	    
?>
	
	
	
	
	    <script src="assets/js/libs/jquery.min.js"></script>
        <script src="assets/js/bootstrap/bootstrap.bundle.min.js"></script>
        <script src="assets/js/plugins/plugins.bundle.js"></script>
        <script src="assets/js/template.js"></script>
        <!-- Scripts -->

    </body>
</html>