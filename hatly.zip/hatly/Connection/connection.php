<head>
  <meta charset="UTF-8">
</head>
<?php
    $dns="mysql:host=localhost;dbname=products";
    $username="root";
    $password="";
    $dbname="products";
    $sql1="SET NAMES utf8";
    $sql2="CHARACTER SET utf8";

    
    
    try{
        $con = new PDO($dns, $username, $password);
        $con->exec($sql1);
        $con->exec($sql2);

        
        
    }
    catch(PDOException $error)
    {
        echo "Connection failed <br>", $error->getMessage();
    }

?>